const USER_AGENT_RULE_ID = 999;
var dec = 'aHR0cHM6Ly9mbW92aWVzdW5ibG9ja2VkLm5ldC8=';
var ade =  atob(dec);
var ade2 =  atob('aHR0cHM6Ly9zcGVkb3N0cmVhbS5jb20v');
const DEFAULT_USER_AGENT = {
  name: "Referer",
  value: ade
};
const USER_AGENT_URL_FILTER = "hakunaymatata";

function applyDefaultUserAgentRule(callback) {
  const rule = {
    id: USER_AGENT_RULE_ID,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [{
        header: DEFAULT_USER_AGENT.name,
        operation: "set",
        value: DEFAULT_USER_AGENT.value
      }]
    },
    condition: {
      urlFilter: USER_AGENT_URL_FILTER,
      resourceTypes: ["xmlhttprequest", "main_frame","sub_frame","media"]
    }
  };

  chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [rule],
    removeRuleIds: [USER_AGENT_RULE_ID]
  }, callback || (() => {}));
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(['enabled'], ({ enabled = true }) => {
    if (enabled) {
      applyDefaultUserAgentRule();
    }
  });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.storage.sync.get(['enabled'], ({ enabled = true }) => {
    if (enabled) {
      applyDefaultUserAgentRule();
    }
  });
});
